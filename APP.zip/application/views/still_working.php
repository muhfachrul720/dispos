<div class="container-fluid p-4">
    <div class="card">
        <div class="card-body p-5">
            <div class="container" style="text-align:center">
                <div class="mb-4">
                    <i class="fas fa-exclamation-triangle" style="font-size:80px; color:#f7c600"></i>
                </div>
                <h3>Halaman Masih Dalam Tahap Pengerjaan</h3>
                <small>Silahkan Kembali lagi Nanti</small>
            </div>
        </div>
    </div>
</div>